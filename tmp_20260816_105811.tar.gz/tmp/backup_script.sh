#!/usr/bin/env bash
# Backup script: creates a timestamped tarball of a given directory.

set -euo pipefail

# Usage message
if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <directory_to_backup>"
    exit 1
fi

SOURCE_DIR="$1"
# If the path is relative, resolve it to absolute
SOURCE_DIR="$(cd "$SOURCE_DIR" 2>/dev/null && pwd || echo "$SOURCE_DIR")"

if [[ ! -d "$SOURCE_DIR" ]]; then
    echo "Error: '$SOURCE_DIR' is not a directory."
    exit 1
fi

# Generate a timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BASENAME=$(basename "$SOURCE_DIR")
ARCHIVE_NAME="${BASENAME}_${TIMESTAMP}.tar.gz"

# Create the archive (excluding .git directories by default)
tar --exclude='**/.git' -czf "$ARCHIVE_NAME" -C "$(dirname "$SOURCE_DIR")" "$BASENAME"

echo "Backup created: $ARCHIVE_NAME"