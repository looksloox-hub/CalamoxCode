from calamox.backend import routes.chat
print([x for x in dir(routes.chat) if not x.startswith('_')])
